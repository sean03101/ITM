def number_of_three(n):
	int i = 0 
    int j = n 
	if n >= 10:
		number_of_three(n%10):
			if(number_of_three = 3 , i++)
                number_of_three(j//10)
                    n = j
                
	else if n = 3 , i++ :
	print(n + "contains" + i + "threes") :
    
    
    
def number_of_three(n): 
    int i = 0
    if n = 3 :
        return i++
    
    else if n>=10:
        return (n % 10 = 3, i++) + number_of_three(n//10)
        
        
    
 def number_of_three(n):
	int i = 0 
	if n >= 10:
		number_of_three(n%10)
			if(number_of_three = 3 , i++)
        n // =  10
                
	else if n = 3: , i++ 
	print(n + "contains" + i + "threes") 
           