def bin_log (n):
    int i == 0 
    if n >= 2:
        bin_log (n//2)i++

    return i 